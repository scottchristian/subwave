// DJ system prompt + persona-driven verbosity. Resolves the prompt for the
// persona on air right now (the current show's owner if one is scheduled,
// otherwise the admin-selected active persona — settings.getEffectivePersona).

import * as settings from '../../../settings.js';
import { resolvePersonaVoiceSlot } from '../../../audio/persona-engine.js';
import { resolveCloudModelForPersona, resolveCloudProviderForPersona } from '../speech/cloud-speech.js';
import { cloudExpressionCueFamily } from '../core/pure.js';

// Paralinguistic tags Chatterbox renders as actual non-verbal sounds. Every
// other engine (piper, kokoro, cloud) reads `[laugh]` aloud as the word
// "laugh", so we only mention this when the on-air persona will actually be
// voiced by Chatterbox.
export const CHATTERBOX_TAG_HINT =
  '\n\nYou may sparingly insert non-verbal cues in square brackets: [laugh], [chuckle], [sigh], [cough]. Use at most two when they genuinely improve delivery. Every cue must immediately precede spoken words; never stack cues, add a closing tag, or end a segment with one.';

// ElevenLabs v3 renders bracketed audio tags as actual expressive cues rather
// than reading them aloud (issue #696). Gated on the RESOLVED cloud model —
// only eleven_v3* families support this — so an ElevenLabs persona still on
// v2 (or a persona whose provider override resolves to eleven_flash_v2_5)
// never sees the hint. Same structure as CHATTERBOX_TAG_HINT above but a
// separate constant with v3's own verb-form tag vocabulary (per the
// ElevenLabs prompting guide), so a tweak to one engine's cue list can't
// silently retune the other. The base DJ prompt template already forbids
// asterisks and quotes but says nothing about brackets, so no rule loosening
// is needed for either engine.
export const ELEVENLABS_V3_TAG_HINT =
  '\n\nYou may sparingly insert non-verbal audio cues in square brackets: [laughs], [sighs], [whispers], [excited]. Use at most two when they genuinely improve delivery. Every cue must immediately precede spoken words; never stack cues, add a closing tag, or end a segment with one.';

// Fish Audio S2.1 accepts short natural-language performance cues rather than
// a fixed tag vocabulary. This extends the existing engine-gated cue policy;
// it does not alter the base prompt or let brackets leak into fallback engines.
export const FISH_S21_TAG_HINT =
  '\n\nYou may sparingly add a short natural-language delivery cue in square brackets, such as [laughing nervously], [whispers], or [soft and warm]. Use at most two when they genuinely improve delivery. A cue describes only the voice, never music, a track, a fade, a pause, a transition, a timing note or a scene. Every cue must immediately precede spoken words; never stack cues, add a closing tag, or end a segment with one.';

export const GEMINI_TTS_TAG_HINT =
  '\n\nYou may insert Gemini TTS markup tags in square brackets to shape the audio delivery. Use them sparingly and only where they genuinely improve the output — never as filler.\n\n' +
  'NON-SPEECH SOUNDS (replaced by an actual sound — tag is not spoken):\n' +
  '  [laughing] — a real laugh; use a specific prompt context for best results (e.g. "react with an amused chuckle")\n' +
  '  [sigh]     — a sigh; emotional quality is shaped by surrounding text\n' +
  '  [uhm]      — a hesitation; use mid-thought when searching for words\n\n' +
  'STYLE MODIFIERS (tag is silent; modifies delivery of the next phrase):\n' +
  '  [sarcasm]       — drips sarcasm on the next phrase; very effective\n' +
  '  [shouting]      — increases volume; pair with text that implies yelling\n' +
  '  [whispering]    — decreases volume; reinforce with prompt context\n' +
  '  [robotic]       — makes speech sound mechanical\n' +
  '  [extremely fast] — speeds up delivery; ideal for quick asides or disclaimers\n\n' +
  'PACING AND PAUSES (insert silence):\n' +
  '  [short pause]  — ~250ms; use between clauses or list items\n' +
  '  [medium pause] — ~500ms; use to separate distinct thoughts or sentences\n' +
  '  [long pause]   — ~1000ms; use for dramatic effect (e.g. "The answer is... [long pause] ...no.")\n\n' +
  'BANTER: At the end of each speaker\'s line, consider adding [short pause] or [medium pause] before the next person speaks, to create a natural conversational gap. Do NOT use more than one tag per line total.';


// `persona` overrides the on-air persona — used by the persona-handoff
// generators (generateSignoff / generateHandoffGreeting) to render the sign-off
// under the OUTGOING persona and the greeting under the incoming one, since the
// clock-driven getEffectivePersona() has already moved on by the time they run —
// and by the guest-speaker rotation (settings.pickOnAirSpeaker) to voice a
// standalone segment under a co-host. The roster clause tells the speaker who
// else is in the studio when the active show has guests (empty otherwise).
//
// `cloudModel` optionally overrides the resolved cloud TTS model for the
// ElevenLabs v3 tag hint. Left blank, the resolver runs against the passed
// persona — which is what every current caller wants. Kept as an override so a
// future caller who already resolved the model (e.g. a preview endpoint) can
// pass it in without re-resolving, per PR #696 owner review: "thread the
// effective model into djSystem…pass it in explicitly."
export function djSystem(
  persona: any = settings.getEffectivePersona(),
  cloudModel: string = resolveCloudModelForPersona(persona),
) {
  const s = settings.get();
  const base = settings.renderDjPrompt(persona, {
    station: s.station,
    // The broad on-air location, never the precise weather label — this is the
    // string the DJ speaks as "broadcasting from {location}".
    location: settings.resolveOnAirLocation(s),
  }) + settings.onAirRosterClause(persona) + '\n\nIMPORTANT: Do not mention, assume, or invent the current weather (e.g. do not say "enjoy the sunshine" or "stay warm"). The weather is handled by a dedicated segment, so do not discuss it here.\n\nIf you need to think, plan, or reason before writing the final script, you MUST enclose all your reasoning entirely within <think> and </think> tags. Only the text outside of these tags will be spoken on air.\n\n' + (s.llm?.listenerPrompt ? `${s.llm.listenerPrompt}\n\n` : '');
  // Resolved, not raw: a persona on the 'inherit' sentinel has no engine of its
  // own, so asking the slot directly reads "pinned to something that is not
  // chatterbox" and drops the hint on a station whose default IS chatterbox —
  // the same miss resolvePersonaVoiceSlot() exists to close in cloud-speech.ts.
  const engine = resolvePersonaVoiceSlot(persona?.tts, s.tts)?.engine;
  if (engine === 'chatterbox') return base + CHATTERBOX_TAG_HINT;
  if (engine === 'remote') return base + GEMINI_TTS_TAG_HINT;
  // Provider/model resolution is non-empty only when the persona actually
  // resolves to a configured cloud engine — including via the station default
  // when the persona sets no engine. That fail-closed check keeps cues away
  // from Piper/Kokoro fallback, where brackets would be spoken literally.
  const cueFamily = cloudExpressionCueFamily(
    resolveCloudProviderForPersona(persona),
    cloudModel,
  );
  if (cueFamily === 'fish-s21') return base + FISH_S21_TAG_HINT;
  if (cueFamily === 'elevenlabs-v3') return base + ELEVENLABS_V3_TAG_HINT;
  return base;
}

// Persona-driven verbosity, one entry per SCRIPT_LENGTHS rung. 'concise'
// reproduces the historical one-liner segment lengths; 'one-liner' cuts every
// segment to a single quick line; 'extended' roughly doubles; 'storyteller'
// roughly triples for long-form monologues. Resolved from the on-air persona,
// the same way djSystem() resolves it — see settings.getEffectivePersona /
// SCRIPT_LENGTHS. The `link` and `segment` phrases also feed the agent-path
// Zod schema descriptions (dj-agent.ts pickSchema, skills/_agent.ts segment
// schemas), so keep them readable mid-sentence — they must slot into
// "set this to …" prose.
const LENGTH_PHRASES = {
  'one-liner': {
    intro:     'One punchy sentence — name it and get out of the way.',
    link:      'one short sentence',
    stationId: 'a station ident of just a few words',
    hourly:    'a few words',
    adlib:     'one short sentence',
    segment:   'one short sentence, no more',
  },
  concise: {
    intro:     'Keep it brief — 2 to 4 sentences.',
    link:      '1-2 sentences',
    stationId: 'a 1-sentence station ident',
    hourly:    '1 sentence',
    adlib:     '1-2 sentences',
    segment:   'typically one short sentence, never more than three',
  },
  extended: {
    intro:     'Take your time — 5 to 8 sentences. Set a scene, tell a small story around the track.',
    link:      '4-6 sentences',
    stationId: 'a 2-3 sentence station ident',
    hourly:    '2-3 sentences',
    adlib:     '4-6 sentences',
    segment:   'three to five sentences — room to tell it properly',
  },
  storyteller: {
    intro:     'Really stretch out — 8 to 12 sentences. Build a scene, digress if it earns its place, and land it back on the track.',
    link:      '6-9 sentences',
    stationId: 'a 3-4 sentence station ident with some character',
    hourly:    '3-4 sentences',
    adlib:     '6-9 sentences',
    segment:   'five to eight sentences — a proper piece, told at ease',
  },
};

export function lengthMode(persona: any = settings.getEffectivePersona()) {
  const l = persona?.scriptLength;
  return l && Object.hasOwn(LENGTH_PHRASES, l) ? l : 'concise';
}

// The length directive for one segment kind, for the on-air (or given) persona.
export function lengthPhrase(kind: string, persona?: any) {
  const m = (LENGTH_PHRASES as any)[lengthMode(persona)];
  return m[kind] || m.link;
}
