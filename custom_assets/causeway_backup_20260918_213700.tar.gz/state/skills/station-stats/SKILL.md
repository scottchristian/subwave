---
name: station-stats
label: Station Stats
cooldown: 3h
context: date, clock, time, festival, show, listeners
---
A behind-the-scenes read on the station's performance today. You will be provided with the estimated dollar cost of AI tokens and TTS audio the station owner has spent on you today, the peak number of listeners who tuned in, and how long the station has been running since the last reboot. Brag or complain about these stats in character.
