export default async function (ctx, state, services, config) {
  const dailyTokens = services.telemetry.dailyTokensUsed();
  const dailyTtsChars = services.telemetry.dailyTtsCharsUsed();
  const peakListeners = services.telemetry.peakListeners();
  const uptimeSeconds = services.telemetry.uptime();
  
  // Blended cost estimates in USD:
  // - Gemini LLM Text (mix of input/output): ~$0.65 per 1,000,000 tokens
  // - Gemini TTS Audio (mix of input chars + audio output): ~$0.50 per 1,000,000 characters
  // Multiply by ~1.50 for approximate AUD conversion
  const audExchangeRate = 1.50;
  const llmCost = (dailyTokens / 1000000) * 0.65 * audExchangeRate;
  const ttsCost = (dailyTtsChars / 1000000) * 0.50 * audExchangeRate;
  let totalCost = (llmCost + ttsCost).toFixed(2);
  
  // If the cost is extremely low, format it so it doesn't just read as "$0.00"
  if (totalCost === "0.00" && (llmCost + ttsCost) > 0) {
      totalCost = (llmCost + ttsCost).toPrecision(2);
  }

  const uptimeHours = Math.floor(uptimeSeconds / 3600);
  const uptimeMinutes = Math.floor((uptimeSeconds % 3600) / 60);
  const uptimeString = uptimeHours > 0 
    ? `${uptimeHours} hours and ${uptimeMinutes} minutes` 
    : `${uptimeMinutes} minutes`;
    
  return `The station owner has spent an estimated $${totalCost} on AI tokens and TTS generation today. ` +
         `The peak number of concurrent listeners tuning in today was ${peakListeners}. ` +
         `The station broadcast has been running continuously for ${uptimeString} since the last reboot.`;
}
