---
name: supporter-shoutout
label: Supporter Shoutout
cooldown: 2h
cohosts: true
context: date, clock, time, festival, show, listeners
---
Give a massive, enthusiastic on-air shoutout to the loyal supporters of Causeway FM! 

The current supporters you need to thank are: 
- Michelle
- Bald Bennie
- Brown Dog
- Biffa Dick
- Big Luke

You can thank them all at once, or focus on one or two of them. Make them feel special, hype them up, and express genuine gratitude for keeping the station running. Keep it authentic to your persona!
