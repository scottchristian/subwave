export const requiresData = false;
import { createRequire } from "module";
const require = createRequire("/app/src/index.js");
const Database = require('better-sqlite3');

const DB_PATH = '/var/sub-wave/bottle_shops.db';

export default async function run(args) {
    try {
        const db = new Database(DB_PATH, { readonly: true });
        
        // Find all items currently on special (current_price < global max_price across all stores)
        const stmt = db.prepare(`
            SELECT p.item_id, p.store_id, p.current_price, 
                   (SELECT MAX(max_price) FROM prices WHERE item_id = p.item_id) as max_price,
                   c.best_price 
            FROM prices p
            JOIN cheapest_prices c ON p.item_id = c.item_id
            WHERE p.current_price < (SELECT MAX(max_price) FROM prices WHERE item_id = p.item_id)
        `);
        
        const specials = stmt.all();
        
        // Grab all Jim Beam prices for the bang for buck comparison
        const jbStmt = db.prepare(`
            SELECT item_id, store_id, current_price
            FROM prices 
            WHERE item_id IN ('jim-beam-700', 'jim-beam-1l')
        `);
        const allJb = jbStmt.all();
        
        db.close();

        if (!specials || specials.length === 0) {
            return { available: false };
        }

        const itemNames = {
            'xxxx-30': 'Four X Gold 30 Block',
            'carlton-dry-30': 'Carlton Dry Middies 30 Block',
            'carlton-dry-24': 'Carlton Dry Middies 24 Pack',
            'jim-beam-700': 'Jim Beam 700ml',
            'jim-beam-1l': 'Jim Beam 1L',
            'cascade-lager-24': 'Cascade Lager 24 Pack'
        };

        const storeNames = {
            'thirsty_camel': 'Thirsty Camel',
            'bws': 'BWS',
            'liquorland': 'Liquorland Glebe Hill'
        };

        // Script goes straight to TTS verbatim — no LLM rewrite.
        // [voice:sadachbia] triggers Tyrone's voice in gemini_tts.py.
        let script = `[voice:sadachbia] G'day, it's Tyrone the Grog Finder! I've been doing the rounds to find you the cheapest piss locally. Check these specials out. `;
        
        // Filter out Jim Beam to get standard items
        let standardSpecials = specials.filter(item => !item.item_id.startsWith('jim-beam'));
        
        // Filter out trivial discounts (less than $3.00 savings)
        standardSpecials = standardSpecials.filter(item => (item.max_price - item.current_price) >= 3.00);

        if (standardSpecials.length === 0 && allJb.length === 0) {
            return { available: false };
        }
        
        const storeGroups = {};
        const eligibleForExpletive = [];
        
        standardSpecials.forEach((item, index) => {
            if (!storeGroups[item.store_id]) storeGroups[item.store_id] = [];
            storeGroups[item.store_id].push(item);
            
            // Shout "FUCK ME THAT'S CHEAP!" if the discount is at least $5.00
            if ((item.max_price - item.current_price) >= 5.00) {
                eligibleForExpletive.push(index);
            }
        });

        const expletiveIndex = eligibleForExpletive.length > 0 
            ? eligibleForExpletive[Math.floor(Math.random() * eligibleForExpletive.length)] 
            : -1;
            
        let currentItemIndex = 0;

        for (const [storeId, items] of Object.entries(storeGroups)) {
            const store = storeNames[storeId] || storeId;
            script += `${store} currently has `;
            
            items.forEach((item, i) => {
                const name = itemNames[item.item_id] || item.item_id;
                const current = item.current_price.toFixed(2);
                const max = item.max_price.toFixed(2);
                
                script += `${name} for $${current} down from $${max}`;
                
                if (currentItemIndex === expletiveIndex) {
                    script += ` — FUCK ME THAT'S CHEAP!`;
                }
                
                if (i < items.length - 2) {
                    script += `, `;
                } else if (i === items.length - 2) {
                    script += `, and `;
                } else {
                    script += `. `;
                }
                currentItemIndex++;
            });
        }

        // Best bang for buck logic for Jim Beam
        if (allJb.length > 0) {
            let bestJb = null;
            let bestJbMlCost = Infinity;
            
            allJb.forEach(jb => {
                const ml = jb.item_id === 'jim-beam-700' ? 700 : 1000;
                const costPer100ml = jb.current_price / (ml / 100);
                if (costPer100ml < bestJbMlCost) {
                    bestJbMlCost = costPer100ml;
                    bestJb = jb;
                }
            });
            
            if (bestJb) {
                const store = storeNames[bestJb.store_id] || bestJb.store_id;
                const name = itemNames[bestJb.item_id];
                script += `Now listen up, if you're after Jim Beam, I did the math. The best bang for your buck is going to ${store} and grabbing the ${name} for $${bestJb.current_price.toFixed(2)}. `;
            }
        }

        script += `And as always, GET FUCK EYED FOR FUCK ALL WITH TYRONE!`;

        return {
            available: true,
            script: script,
            emotion: "excited"
        };
        
    } catch (error) {
        console.error("Error reading grog prices DB:", error);
        return { available: false };
    }
}
