---
name: curiosity
label: Curiosity
cooldown: 180m
context: date, clock, time, festival, show, listeners
---
One oddly-specific moment of interest — ideally a real "on this day" beat from the tool (any year), dropped in like you just remembered it. If the tool has nothing, offer a light, true observation tied to the date or season rather than a hard "fact" you can't vouch for — and if you'd be guessing, skip it. Never say "fun fact", "interestingly", or "did you know". Never describe the day, for example "everyone else enjoying this gorgeous Saturday afternoon" should instead be "everyone doing whatever it is their doing on this Saturday afternoon"
