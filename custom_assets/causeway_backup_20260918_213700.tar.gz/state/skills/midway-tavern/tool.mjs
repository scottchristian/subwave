export const configFields = [];

export default async function run(context, params) {

  // Convert current time to Hobart/Tasmania timezone
  const now = new Date();
  const hobartTime = new Intl.DateTimeFormat('en-AU', {
    timeZone: 'Australia/Hobart',
    weekday: 'long',
    hour: 'numeric',
    hour12: false
  }).format(now);

  const parts = hobartTime.split(', ');
  const day = parts[0];
  const hour = parseInt(parts[1], 10);

  // Thursday, Friday, Saturday
  const validDays = ['Thursday', 'Friday', 'Saturday'];
  
  // Afternoon window (e.g., 2 PM to 5 PM, so they can announce it leading up to or during happy hour)
  const isAfternoon = hour >= 14 && hour < 18;

  if (validDays.includes(day) && isAfternoon) {
    return { 
      available: true, 
      data: {
        special: "$6 schooners",
        time: "4 PM to 6 PM",
        day: day
      }
    };
  }

  // If outside the window, skill is disabled
  return { available: false };
}
