---
name: midway-tavern
label: Midway Tavern Happy Hour
cooldown: 1h
window: any
---
It's Thursday, Friday, or Saturday afternoon, and Happy Hour at the Midway Point Tavern runs from 4 PM to 6 PM.
Announce to the listeners that happy hour is happening and they should come on down for $6 schooners!
Keep it natural for a radio station.
