// Custom data tool for SUB/WAVE — picks a random story theme for the
// "story-gay-lifestyle" segment, so the DJ riffs on a concrete premise
// instead of being asked to "randomly pick a number" itself (LLMs are bad
// at dice). The church-of-reason / gay-lifestyle framing choice stays with
// the DJ in SKILL.md, not this tool.
//
// Signature: (ctx, state, services, config, input) => data
//   ctx      — the moment (time, weather, festival, dominantMood, clock)
//   state    — cross-tick memory, persists between firings
//   services — the station facade (searchWeb, library, nowPlaying, log, …)
//   config   — this skill's own SKILL.md frontmatter
//   input    — agent-steerable params (none declared here)
// This tool has no external dependency, so it always has something to hand
// back - { available: false } is never returned.

export const description =
  'Pick a random story theme for this segment. Returns { available, theme }.';

const THEMES = [
  "The tax benefits of partnering up with another man, even though you don't swing that way — doing the gay things would be a struggle but totally worth it because you don't have the constant irritation of a woman",
  'On your birthday, the boys get you a hooker and some coke because they know you and know what you like',
  "Over-engineered bachelor pads, no one got upset as your mates don't judge",
  'Copping a flogging from mates because you cheaped out and purchased a lesser model of some sort of item in your house when something bigger and better was available',
  'Mental overseas holidays with the boys filled with drinking and drugs',
  'Ridiculous house modifications to allow stashing more booze, not one of my mates got upset',
  'I said I was going to have a beer before 12pm and no one got upset',
  'Only eating red meat for dinner, no one got upset because men are men',
  'Drunk eBay purchases at 3am that turn up unexpectedly a week later — no one gets upset',
];

function pick(list) {
  return list[Math.floor(Math.random() * list.length)];
}

export default async function (ctx, state, services, config, input) {
  let theme = pick(THEMES);

  // Don't hand back the exact same theme twice in a row.
  if (state.lastTheme === theme) {
    theme = pick(THEMES);
  }
  state.lastTheme = theme;

  services.log(`story-gay-lifestyle: picked theme "${theme}"`);

  return { available: true, theme };
}
