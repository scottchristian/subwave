---
name: story-gay-lifestyle
label: Story - The Gay Lifestyle
cooldown: 2h
context: date, clock, time, show
tags: comedy
---
A tool call already picked one random story theme above. Come up with a
short story based on that theme. No more than 4 sentences. Must start by saying that it's a story that someone has sent in to the radio station.

Don't restate the theme verbatim or describe it, spin it into a scene. Keep
it cocky and unhinged - a half-remembered fragment of a story about living
loud, and doing whatever you want because nobody's stopping you. Never the
full tale, just a chaotic glint of the good life. Make it a story, not an
explanation. Don't focus too heavily on the money.
Introduce it as another story from either "the church of reason" or "the gay lifestyle" with 50% probability.
