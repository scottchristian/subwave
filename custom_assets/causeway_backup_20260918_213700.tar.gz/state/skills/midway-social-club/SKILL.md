---
name: midway-social-club
label: Midway Tavern Social Club
description: "A skill that reads the latest posts from the local Midway Tavern Social Club Facebook group."
cooldown: 60m
context: date, clock, time, festival, show, listeners
---

# Midway Tavern Social Club
You can use this skill to find out if there are any new announcements or posts from the Midway Tavern Social Club. 
When you read a post, mention that it's from the Midway Tavern Social Club Facebook group. Make it sound like you're giving the listeners a local community update.

Output requirements:
- ONLY output the spoken response.
- Do NOT output any stage directions or actions.
