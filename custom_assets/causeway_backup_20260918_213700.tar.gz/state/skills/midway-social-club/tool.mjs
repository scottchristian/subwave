import fs from 'fs';
import path from 'path';

export default async function (ctx, state, services, config, input) {
  try {
    const dataPath = path.join(process.cwd(), 'state', 'social_club_posts.json');
    if (!fs.existsSync(dataPath)) {
      return { available: false, error: 'No social club data found.' };
    }

    const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
    const posts = data.posts || [];

    if (posts.length === 0) {
      return { available: false, error: 'No posts available.' };
    }

    // Find up to 2 unread posts
    const newPosts = [];
    for (const post of posts) {
      if (newPosts.length >= 2) break;
      
      const hash = encodeURIComponent(post.substring(0, 50));
      
      if (services && services.recall) {
        if (await services.recall.seen(`social_club_post_v2_${hash}`)) {
          continue;
        }
      }
      
      newPosts.push(post);
      
      if (services && services.recall) {
        await services.recall.remember(`social_club_post_v2_${hash}`);
      }
    }

    if (newPosts.length === 0) {
      return { available: false }; // No fresh posts right now
    }

    return {
      available: true,
      posts: newPosts
    };
    
  } catch (err) {
    if (services && services.log) services.log(`Social club fetch error: ${err.message}`);
    return { available: false, error: err.message };
  }
}
