---
name: waze-alerts
description: Fetches and announces live speed traps, police reports, hazards, and traffic jams from Waze for the local area.
trigger: autonomous
---

# Waze Alerts Skill

This skill queries a local SQLite database populated by a background Waze scraper. It checks for active police, hazards, and traffic jams in the Midway Point, Cambridge, and Sorell area.

If there are active alerts, it outputs a pre-written script featuring the Tyrone voice reading the alerts.
If there are no alerts, it gracefully stands down by returning `{ available: false }`.
