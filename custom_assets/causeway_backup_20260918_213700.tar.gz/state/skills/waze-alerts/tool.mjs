import { createRequire } from "module";
const require = createRequire("/app/src/index.js");
const Database = require('better-sqlite3');
import path from "path";
import fs from "fs";

export const requiresData = false;

function getAlerts() {
    const dbPath = "/app/state/waze_alerts.db";
    if (!fs.existsSync(dbPath)) {
        return { alerts: [], jams: [] };
    }
    
    try {
        const db = new Database(dbPath, { readonly: true });
        // Only get alerts from the last 2 hours to ensure freshness
        const twoHoursAgo = Math.floor(Date.now() / 1000) - (2 * 60 * 60);
        
        const alerts = db.prepare('SELECT * FROM alerts WHERE timestamp > ?').all(twoHoursAgo);
        const jams = db.prepare('SELECT * FROM jams WHERE timestamp > ?').all(twoHoursAgo);
        
        db.close();
        return { alerts, jams };
    } catch (error) {
        console.error("Failed to read Waze DB:", error);
        return { alerts: [], jams: [] };
    }
}

export default async function run(agent, params) {
    const { alerts, jams } = getAlerts();
    
    // Filter to things we actually care about: POLICE, HAZARD, ACCIDENT
    const policeAlerts = alerts.filter(a => a.type === 'POLICE');
    const hazardAlerts = alerts.filter(a => a.type === 'HAZARD' || a.type === 'ACCIDENT');
    // For jams, only report significant ones (level 3 or 4)
    const heavyJams = jams.filter(j => j.level >= 3);
    
    if (policeAlerts.length === 0 && hazardAlerts.length === 0 && heavyJams.length === 0) {
        return { available: false };
    }
    
    // Construct the script
    let scriptLines = [
        "[voice:sadachbia] Tyrone here with a quick traffic update for the area."
    ];
    
    if (policeAlerts.length > 0) {
        // Group by street if possible
        const locations = policeAlerts.map(a => a.street || 'the area').filter(s => s !== 'the area');
        if (locations.length > 0) {
            scriptLines.push(`Watch your speed out there, someone's reported a speed camera or police presence on ${locations[0]}.`);
        } else {
            scriptLines.push("Watch your speed, there's a reported speed camera in the area.");
        }
    }
    
    if (hazardAlerts.length > 0) {
        const hazard = hazardAlerts[0];
        const street = hazard.street ? `on ${hazard.street}` : "in the area";
        scriptLines.push(`Also heads up, there is a reported hazard or accident ${street}, so keep your eyes peeled.`);
    }
    
    if (heavyJams.length > 0) {
        const jam = heavyJams[0];
        const street = jam.street ? `on ${jam.street}` : "nearby";
        const delayMins = Math.round(jam.delay / 60);
        scriptLines.push(`Traffic is looking a bit heavy ${street} right now, expect a delay of about ${delayMins} minutes if you're heading that way.`);
    }
    
    scriptLines.push("Keep it safe and stick with Causeway FM!");
    
    return {
        available: true,
        script: scriptLines.join(" ")
    };
}
