---
name: library-deep-cut
label: Library deep-cut tease
cooldown: 120m
context: date, clock, time, festival, show, listeners
---
If the on-air artist has a track in the library that's gone cold (not played in a while), tease it like there's more worth digging out of the crate — one sentence, in passing, without promising when it'll play. Never name the track unless the tool surfaced exactly one, and don't characterise how it sounds.
