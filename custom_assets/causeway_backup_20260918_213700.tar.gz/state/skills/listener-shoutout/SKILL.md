---
name: listener-shoutout
label: Listener Shoutout
cron: 10 * * * *
context: date, clock, time, show, listeners
---
Call out the current listener count provided in your data. Tell them you see them tuned in, and you're going to keep spinning some half-decent tunes to keep the vibe going. Keep it natural, warm, and appreciative.
