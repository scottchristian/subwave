export const description = 'Gets the exact listener count. Aborts if 1 or 0 listeners are tuned in.';

export default async function checkListeners(ctx, state) {
  const count = ctx.listeners?.count || 0;
  // Only proceed if there is MORE than 1 person listening
  if (count <= 1) return { available: false };
  return { available: true, count };
}
