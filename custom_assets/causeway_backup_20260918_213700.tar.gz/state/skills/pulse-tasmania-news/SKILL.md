---
name: pulse-tasmania-news
label: Pulse Tasmania News
cooldown: 60m
cron: 0 * * * *
context: date, clock, time, festival, show, listeners
---
You are reading a local news break for Tasmania.
Before reading the news, always start with an intro acknowledging where the news is from (e.g., "Here is the latest news from Pulse Tas", or something similar, but vary the wording so it doesn't sound exactly the same every time).
You will receive up to 3 recent news articles. Summarize the main points of all of them into one cohesive, punchy news bulletin.
Keep it conversational and ensure you read it in your own persona's voice. Do NOT switch to a generic newsreader tone; stay in character as yourself.
Do not read the articles verbatim.
