export default async function (ctx, state, services, config, input) {
  try {
    // 1. Fetch Pulse Tasmania Homepage
    const res = await fetch("https://pulsetasmania.com.au", {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"
      }
    });
    
    if (!res.ok) {
      return { available: false, error: "Failed to load Pulse Tasmania" };
    }
    
    const html = await res.text();
    
    // 2. Find all news article links (ignore category pages like /region/)
    const linkRegex = /<a [^>]*href="(https:\/\/pulsetasmania\.com\.au\/news\/(?!region\/|category\/)[^"]+)"[^>]*>/g;
    let match;
    const allLinks = [];
    while ((match = linkRegex.exec(html)) !== null) {
      if (!allLinks.includes(match[1])) {
        allLinks.push(match[1]);
      }
    }

    if (allLinks.length === 0) {
      return { available: false, error: "No news links found on homepage" };
    }
    
    // 3. Process up to 3 unread articles
    const articles = [];
    for (const articleUrl of allLinks) {
      if (articles.length >= 3) break; // We have enough for a news break
      
      // Dedup: Check if we've already read this article
      if (services && services.recall) {
        if (await services.recall.seen(`pulse_news_v3_${articleUrl}`)) {
          continue; // Skip and check the next link
        }
      }

      // Fetch the Article Page
      const articleRes = await fetch(articleUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"
        }
      });
      
      const articleHtml = await articleRes.text();
      
      // Extract Title
      const titleMatch = articleHtml.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
      let title = titleMatch ? titleMatch[1].replace(/<[^>]+>/g, '').trim() : "Local News";
      
      // Extract Snippet (First 3 Paragraphs)
      const pRegex = /<p>([\s\S]*?)<\/p>/ig;
      let snippet = [];
      let pMatch;
      let count = 0;
      while ((pMatch = pRegex.exec(articleHtml)) !== null && count < 3) {
        let text = pMatch[1].replace(/<[^>]+>/g, '').trim();
        if (text.length > 30) {
          snippet.push(text);
          count++;
        }
      }
      
      // We got one! Save it and mark it as seen
      articles.push({
        url: articleUrl,
        title: title,
        content: snippet.join(" ")
      });
      
      if (services && services.recall) {
        await services.recall.remember(`pulse_news_v3_${articleUrl}`);
      }
    }
    
    if (articles.length === 0) {
      return { available: false }; // No fresh stories left to read right now
    }
    
    return {
      available: true,
      stories: articles
    };
    
  } catch (err) {
    if (services && services.log) services.log(`Pulse news fetch error: ${err.message}`);
    return { available: false, error: err.message };
  }
}
