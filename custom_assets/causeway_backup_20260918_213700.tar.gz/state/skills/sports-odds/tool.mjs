export const requiresData = false;
import { createRequire } from "module";
const require = createRequire("/app/src/index.js");
const Database = require('better-sqlite3');

const DB_PATH = '/var/sub-wave/sports_odds.db';

function formatOdds(num) {
    const dollars = Math.floor(num);
    const cents = Math.round((num % 1) * 100);
    
    if (dollars === 1 && cents === 0) return "a buck";
    if (dollars === 1 && cents > 0) return "a dollar " + cents;
    if (dollars > 1 && cents === 0) return dollars + " bucks";
    if (dollars > 1 && cents > 0) return dollars + " bucks " + cents;
    if (dollars === 0) return cents + " cents";
    return num.toString();
}

export default async function run(args) {
    try {
        const db = new Database(DB_PATH, { readonly: true });
        
        const aflStmt = db.prepare(`SELECT * FROM odds WHERE sport = 'AFL' ORDER BY start_time ASC LIMIT 2`);
        const ufcStmt = db.prepare(`SELECT * FROM odds WHERE sport = 'UFC' ORDER BY start_time ASC LIMIT 2`);
        
        const aflMatches = aflStmt.all();
        const ufcMatches = ufcStmt.all();
        db.close();

        if (aflMatches.length === 0 && ufcMatches.length === 0) {
            return { available: false };
        }

        let script = `[voice:sadachbia] G'day, it's Tyrone here with your sports betting odds. If you're looking to lay a cheeky punt, listen up. `;

        if (aflMatches.length > 0) {
            script += `In the AFL this week, `;
            aflMatches.forEach((match, i) => {
                script += `${match.participant1} is paying ${formatOdds(match.odds1)} to win against ${match.participant2} at ${formatOdds(match.odds2)}`;
                if (i < aflMatches.length - 1) {
                    script += `, and `;
                } else {
                    script += `. `;
                }
            });
        }

        if (ufcMatches.length > 0) {
            script += `Over in the octagon for the UFC, `;
            ufcMatches.forEach((match, i) => {
                script += `${match.participant1} is at ${formatOdds(match.odds1)} taking on ${match.participant2} paying ${formatOdds(match.odds2)}`;
                if (i < ufcMatches.length - 1) {
                    script += `, and `;
                } else {
                    script += `. `;
                }
            });
        }

        script += `Remember to gamble responsibly, but more importantly, RIP IN AND BACK A WINNER WITH TYRONE!`;

        return {
            available: true,
            script: script,
            emotion: "excited"
        };
        
    } catch (error) {
        console.error("Error reading sports odds DB:", error);
        return { available: false };
    }
}
