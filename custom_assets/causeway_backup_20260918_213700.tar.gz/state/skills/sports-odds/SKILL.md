---
name: sports-odds
label: Tyrone's Sports Odds
cooldown: 3h
context: date, clock, time
toolDescription: "Gets the latest upcoming match odds for AFL and UFC from Sportsbet. Returns a pre-written script listing the odds or { available: false } if there are no upcoming matches."
---
Read out the script provided by the tool verbatim. Be enthusiastic and casual.

IMPORTANT: DO NOT hallucinate any odds or matches that are not explicitly provided in the script.
